# Runs after the program exits: copies the new version over it and starts it again. Started by update.py.
param([int]$ProcId, [string]$Src, [string]$Dst, [string]$Exe)
try { Wait-Process -Id $ProcId -Timeout 60 -ErrorAction SilentlyContinue } catch {}
Start-Sleep -Milliseconds 800
$ok = $false
for ($i = 0; $i -lt 5 -and -not $ok; $i++) {
    try {
        Copy-Item -Path (Join-Path $Src '*') -Destination $Dst -Recurse -Force -ErrorAction Stop
        $ok = $true
    } catch { Start-Sleep -Seconds 2 }
}
if ($ok) { Remove-Item -LiteralPath $Src -Recurse -Force -ErrorAction SilentlyContinue }
Start-Process -FilePath (Join-Path $Dst $Exe) -WorkingDirectory $Dst
